# Scraper Bot

This is the code for a Discord bot that reads the message history of a specified channel and turns into a .csv file containing
the time it was sent in, the author and the content of the message itself. It requires permission to view channels and read 
message history.

This bot is already running, so if you'd rather invite it into your server, use the following invite link:

https://discord.com/api/oauth2/authorize?client_id=773341913906151454&permissions=66560&scope=bot
